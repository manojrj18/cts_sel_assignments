package logger;

import org.apache.log4j.Logger;

public class log_file {
public static void main(String [] args) 
  {
	Logger log = Logger.getLogger("devpinoyLogger");
			log.debug("lock down due to covid 19");
  }
}
