package pkg_maven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  
	  System.out.println("in testng");
	         System.setProperty("webDriver, chrome.Driver","chromedriver_v80.exe");
	         WebDriver dr = new ChromeDriver();
	         dr.get("https://www.saucedemo.com/");
  }
}
