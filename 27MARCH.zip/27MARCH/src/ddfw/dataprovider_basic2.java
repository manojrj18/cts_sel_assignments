package ddfw;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_basic2 {
	basic_testlogin test;
  @Test(dataProvider="login_data")
  public void logintest(String eid,String pwd,String exp_eid) {
	  test =new basic_testlogin();
	  String a_eid=basic_testlogin.login(eid,pwd);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(a_eid, exp_eid);
	  sa.assertAll();
  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data(){
	  String[][] data= {
			  {"manojrj18@gmail.com","manubaby","manojrj18@gmail.com"},
			  {"manojrj18@gmail.com","manubaby","manojrj1@gmail.com"}
	  };
	  return data;
  }
}
