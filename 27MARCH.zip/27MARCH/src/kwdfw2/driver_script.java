package kwdfw2;

public class driver_script {
	public static void main(String[] args) {	
		excel_operations excel= new excel_operations();
		
		excel.write_excel(0, 0,"selenium");
		
		excel.write_excel2(1, 2,"selenium");
		
		excel.write_excel3(4, 4,"selenium");
	}

}


