package testjpet;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login {
public static String login(String uid, String pwd) {
System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
WebDriver dr = new ChromeDriver();
dr.get("https://jpetstore.cfapps.io/login");
dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[1]")).sendKeys(uid);
dr.findElement(By.xpath("//*[@id=\"Catalog\"]/form/p[2]/input[2]")).sendKeys(pwd);
dr.findElement(By.xpath("//*[@id=\"login\"]")).click();
String a_eid = dr.findElement(By.xpath("//*[@id=\"WelcomeContent\"]/div")).getText();
dr.close();
return a_eid;
}

}
