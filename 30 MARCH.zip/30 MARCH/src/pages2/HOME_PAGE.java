package pages2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HOME_PAGE {
WebDriver dr1;
By login_link=By.linkText("Log in");
public HOME_PAGE(WebDriver dr) {
this.dr1=dr;
}
public String verify_title() {
String str=dr1.getTitle();
return str;
}
}