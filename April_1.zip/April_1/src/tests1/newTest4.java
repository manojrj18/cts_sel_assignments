package tests1;

import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.excel.excel_io_arr;

import pages.loginpage1;
import pages.productpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
public class newTest4 extends excel_io_arr {
WebDriver dr;
loginpage1 lp;
productpage pp;


@BeforeMethod
 public void launchbrowser() {
// System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
// dr4 = new ChromeDriver();
 dr = utilities.launch_browser("chrome","https://www.saucedemo.com/");
 lp = new loginpage1(dr);
 pp = new productpage(dr);
 }
 
@BeforeClass
 public void get_data() {
 get_test_data();
 }

  @Test(dataProvider="login_data")
  public void login(String eid, String pwd, String expLabel) {
 lp.do_login(eid, pwd);
pp.verify_text(expLabel);
  }
  @DataProvider(name="login_data")
  public String[][] provide_data() {
    return testdata;
  }
  @AfterClass
  public void close() {
 dr.close();
  }
 
 

}
