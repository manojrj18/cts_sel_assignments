package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage1 {
WebDriver dr3;
By emlid = By.id("user-name");
By passwd = By.id("password");
By loginbtn = By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
public loginpage1(WebDriver dr) {
this.dr3=dr;
}
public void enter_emailid(String emailid) {
dr3.findElement(emlid).sendKeys(emailid);
}
public void enter_password(String password) {
dr3.findElement(passwd).sendKeys(password);
}
    public void click_loginbtn() {
    dr3.findElement(loginbtn).click();
    }
    public void do_login(String emailid, String password) {
    this.enter_emailid(emailid);
    this.enter_password(password);
    this.click_loginbtn();

}
}
