package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class Home_Page {
	

	
	WebDriver dr1;
	By login_link=By.linkText("Log in");
	public Home_Page(WebDriver dr) {
	this.dr1=dr;
	}
	public void click_login_link() {
	dr1.findElement(login_link).click();
	}
	}


