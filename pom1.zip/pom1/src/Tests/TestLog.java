package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Home_Page;
import Pages.Login_Page;

public class TestLog {
WebDriver dr;
Home_Page hp;
Login_Page lp;
 
  @Test
  public void logintest1() {
 hp.click_login_link();
 lp.do_login("manojrj18@gmail.com", "manubaby");
  }
  @BeforeClass
  public void launchbrowser() {
 System.setProperty("webdriver.chrome.driver", "F://Eclipse workspace//chromedriver_win32//chromedriver.exe/");
 dr =new ChromeDriver();
 dr.get("http://demowebshop.tricentis.com/");
 hp=new Home_Page(dr);
 lp=new Login_Page(dr);
  }

}
