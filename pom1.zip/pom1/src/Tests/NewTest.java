package Tests;



import Pages.Home_Page;
import Pages.Login_Page;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class NewTest {
	WebDriver dr;
    Home_Page hp;
    Login_Page lp;
  @BeforeClass
  public void launchbrowser() {
	  System.setProperty("webdriver.chrome.driver", "F://Eclipse workspace//chromedriver_win32//chromedriver.exe/");
	  dr =new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  hp=new Home_Page(dr);
	  lp=new Login_Page(dr);
	  }
  @Test
  public void logintest1() {
 hp.click_login_link();
 lp.do_login("manojrj18@gmail.com", "manubaby");
  }
  
  @AfterClass
  public void closebrowser() {
	  dr.close();
  }

}
