package saucetests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import saucedemo.HomePageSauce;


public class TestSause {
WebDriver dr;
HomePageSauce hp;

 
  @Test
  public void logintest1() {
 hp.click_login_btn();
 hp.do_login("standard_user", "secret_sauce");
  }
  @BeforeClass
  public void launchbrowser() {
 System.setProperty("webdriver.chrome.driver", "F://Eclipse workspace//chromedriver_win32//chromedriver.exe/");
 dr =new ChromeDriver();
 dr.get("http://www.saucedemo.com/");
 hp=new HomePageSauce(dr);
 
  }

}
