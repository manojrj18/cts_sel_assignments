package saucedemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePageSauce {
WebDriver dr1;
By un =By.id("user-name");
By pwd=By.id("password");
By log_btn=By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]");
public HomePageSauce(WebDriver dr) {
this.dr1=dr;
}
public void enter_username(String username) {
dr1.findElement(un).sendKeys(username);
}
public void enter_password(String password) {
dr1.findElement(pwd).sendKeys(password);
}
public void click_login_btn() {
dr1.findElement(log_btn).click();
}
public void do_login(String username,String password) {
this.enter_username(username);
this.enter_password(password);
this.click_login_btn();

}
}
