package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class productpage {
WebDriver dr1;
public productpage(WebDriver dr) {
this.dr1=dr;
}
public void verify_text(String expLabel) {
String actLabel=dr1.findElement(By.className("product_label")).getText();
 Assert.assertEquals(actLabel, expLabel);
 {
 System.out.println("Label matches");
 }
}

}
