package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="FEATURES",glue="STEP_DEF")
public class testrun extends AbstractTestNGCucumberTests {

}

