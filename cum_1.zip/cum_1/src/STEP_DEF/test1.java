package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
WebDriver dr;
@Given("^Login page is displayed$")
public void login_page_is_displayed() throws Throwable {
System.out.println("Login page is displayed");
System.setProperty("webdriver.chrome.driver","F://Eclipse workspace//chromedriver_win32//chromedriver.exe/");
dr= new ChromeDriver();
dr.get("http://demowebshop.tricentis.com/");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a"));

}

@When("^User enters valid data and clicks ok button$")
public void user_enters_valid_data_and_clicks_ok_button() throws Throwable {
dr.findElement(By.className("ico-login")).click();
dr.findElement(By.id("Email")).sendKeys("manojrj18@gmail.com");
dr.findElement(By.id("Password")).sendKeys("manubaby");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

}

@Then("^Homepage is displayed$")
public void homepage_is_displayed() throws Throwable {
String act_txt=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
SoftAssert sa=new SoftAssert();

sa.assertEquals(act_txt, "manojrj@gmail.com");
}

@When("^User enters invalid data and clicks ok button$")
public void user_enters_invalid_data_and_clicks_ok_button1() throws Throwable {
	dr.findElement(By.className("ico-login")).click();
	dr.findElement(By.id("Email")).sendKeys("manojrj8@gmail.com");
	dr.findElement(By.id("Password")).sendKeys("manubaby123");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();

}

@Then("^login page is displayed with error message-no customer account found$")
public void login_page_is_displayed_with_error_message_no_customer_account_found1() throws Throwable {
  
	String a_eid = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
	String exp_eid ="No customer account found";
	
	Assert.assertEquals(a_eid,exp_eid);
	
	{
		System.out.println("label is matched");
	}
	}
}









