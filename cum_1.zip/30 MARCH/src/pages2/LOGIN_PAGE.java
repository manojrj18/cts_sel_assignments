package pages2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LOGIN_PAGE {
WebDriver dr2;
@FindBy(id="user-name")
WebElement eid;
@FindBy(id="password")
WebElement pwd;
@FindBy(className="inventory_item_name")
WebElement prd;
@FindBy(xpath="//input[@value='LOGIN']")
WebElement log_btn;
By txt=new By.ByClassName("product_label");
public LOGIN_PAGE(WebDriver dr) {
this.dr2=dr;
PageFactory.initElements(dr, this);
}
public void enter_email(String emailid) {
eid.sendKeys(emailid);
}
public void enter_password(String password) {
pwd.sendKeys(password);
}
public void click_login_btn() {
log_btn.click();
}
public void do_login(String emailid,String password) {
this.enter_email(emailid);
this.enter_password(password);
this.click_login_btn();
}
public void successful_login() {
System.out.println("Login successful");
}
public String verify_text() {
String st1=prd.getText();
return st1;
}
public String verify_product(WebDriver dr) {
this.dr2=dr;
String act_pro=dr2.findElement(txt).getText();
return act_pro;
}
}
