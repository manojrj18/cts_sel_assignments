package tests2;

import org.testng.annotations.Test;

import pages2.HOME_PAGE;
import pages2.LOGIN_PAGE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class NewTest {
WebDriver dr;
HOME_PAGE hp;
LOGIN_PAGE lp;

@BeforeClass
public void launchbrowser() {
  System.setProperty("webdriver.chrome.driver", "\"F:\\Eclipse workspace\\chromedriver_win32\\chromedriver.exe\"");
  dr =new ChromeDriver();
  dr.get("https://www.saucedemo.com/");
  hp=new HOME_PAGE(dr);
  lp=new LOGIN_PAGE(dr);
  }

@Test
public void logintest1() {
String Title_str=hp.verify_title();
String exp_str="Swag Labs";
Assert.assertEquals(Title_str,exp_str);
lp.do_login("standard_user", "secret_sauce");
lp.successful_login();
String st1=lp.verify_text();
System.out.println(st1);

}

@Test
public void product_test1() {
String act_pro=lp.verify_product(dr);
Assert.assertEquals(act_pro, "Products");
}
}
