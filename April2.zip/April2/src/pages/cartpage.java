package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cartpage {
WebDriver dr2;
public cartpage(WebDriver dr) {
this.dr2=dr;
}
public String verify_name() {
String actname=dr2.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
return actname;
}
public String verify_price() {
String actprice=dr2.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[1]/div[3]/div[2]/div[2]/div")).getText();
return actprice;
}
}