package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class productpage {
WebDriver dr1;
public productpage(WebDriver dr) {
this.dr1=dr;
}
public String verify_text() {
String actLabel=dr1.findElement(By.className("product_label")).getText();
return actLabel;
}
public void click_atc() {
dr1.findElement(By.xpath("//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button")).click();
}
public void click_c(){
dr1.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/svg/path")).click();

}


}

