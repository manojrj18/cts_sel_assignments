package tests1;

import org.testng.annotations.Test;

import com.baseclass.utilities;
import com.excel.excel_io_arr;

import pages.cartpage;
import pages.loginpage1;
import pages.productpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
public class newTest4 extends excel_io_arr {
WebDriver dr;
loginpage1 lp;
productpage pp;
cartpage cp;
String eid ="standard_user",pwd ="secret_sauce",expLabel = "Products";

@BeforeMethod
 public void launchbrowser() {
 dr = utilities.launch_browser("chrome","https://www.saucedemo.com/");
 lp = new loginpage1(dr);
 pp = new productpage(dr);
 cp = new cartpage(dr);
 }
@Test
  public void login() {
 lp.do_login(eid, pwd);
      String actLabel = pp.verify_text();
      String expLabel = "Products";
      Assert.assertEquals(actLabel, expLabel);
      {
     System.out.println("Label matches");
      }
}
@Test
public void verifyname() {
lp.do_login(eid, pwd);
pp.click_atc();
pp.click_c();
String actname = cp.verify_name();
String expname = "Sauce Labs Backpack";
Assert.assertEquals(actname, expname);
     {
     System.out.println("name matches");
     }

}
@Test
public void verifyprice() {
lp.do_login(eid, pwd);
pp.click_atc();
pp.click_c();
String actprice = cp.verify_price();
String expprice = "29.99";
Assert.assertEquals(actprice, expprice);
     {
     System.out.println("price matches");
     }
}
@AfterMethod
  public void close() {
 dr.close();
 }
  }
